/* Hover effect example */
