<?php


unlink('./png');

?>